var api = "https://your-api.pool.com:4010";
var apiMerged = "";
let parentCoin = ""

var email = "";
var telegram = "";
var discord = "";
var facebook = "";

var marketCurrencies = ["{symbol}-BTC", "{symbol}-USD", "{symbol}-EUR", "{symbol}-CAD"];

var blockchainExplorer = "https://explorer.armornetwork.org/{symbol}/block/{id}";
var blockchainExplorerMerged = "https://explorer.armornetwork.org/?hash={id}#block";
var transactionExplorer = "https://explorer.armornetwork.org/{symbol}/transaction/{id}";
var transactionExplorerMerged = "https://explorer.armornetwork.org/?hash={id}#transaction";

var themeCss = "themes/default.css";
var defaultLang = 'en';
