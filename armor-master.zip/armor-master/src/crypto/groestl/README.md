Implementation included from NIST submission package

http://www.groestl.info/implementations.html

We've included Optimized_32bit folder without any modifications
