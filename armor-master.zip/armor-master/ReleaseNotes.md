## Release Notes

### v0.1.0
 - Updated for V5

### v0.0.3
 - Seed nodes updated
 - Check points updated

### v0.0.2

 - Initial release
