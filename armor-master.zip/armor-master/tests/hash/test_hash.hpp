// Copyright (c) 2012-2018, The CryptoNote developers, The Bytecoin developers.
// Licensed under the GNU Lesser General Public License. See LICENSE for
// details.

#pragma once

#include <string>

void test_hashes(const std::string &test_vectors_folder);