Testsuite is from http://www.json.org/JSON_checker/

We modified 18 and added 34, 35 to reflect our depth limit