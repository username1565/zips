// Copyright (c) 2012-2018, The CryptoNote developers, The Bytecoin developers.
// Licensed under the GNU Lesser General Public License. See LICENSE for
// details.

#pragma once

#include <string>
#include "common/CommandLine.hpp"

void test_wallet_state(common::CommandLine &cmd);
