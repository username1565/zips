//
// Created by user on 21-1-19.
//

#pragma once

#ifndef BYTECOIN_BENCHMARKS_HPP
#define BYTECOIN_BENCHMARKS_HPP

#include <ostream>

void benchmark_crypto_ops(size_t count, std::ostream &out);

#endif  // BYTECOIN_BENCHMARKS_HPP
