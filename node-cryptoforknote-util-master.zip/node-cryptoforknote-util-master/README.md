Node-CryptoForkNote-Util with Merged Mining support
===================================================

Installing locally and testing
-----
```
npm install https://github.com/MoneroOcean/node-cryptoforknote-util
```

Dependencies
------------

* Boost (http://www.boost.org/)