# Armor block explorer (AMX)

### How to start server:

* Run `armord` on your machine or find another armor node https://github.com/armornetworkdev/armor
* Rename `.env.example` to `.env` and update `NODE_ADDRESS` and `PORT` value if needed
* `npm ci`
* `npm start`

### How to stop server:

* `npm stop`
