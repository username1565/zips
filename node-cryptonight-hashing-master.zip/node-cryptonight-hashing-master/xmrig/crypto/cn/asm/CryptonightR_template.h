// Auto-generated file, do not edit

extern "C"
{
	void CryptonightR_template_part1();
	void CryptonightR_template_mainloop();
	void CryptonightR_template_part2();
	void CryptonightR_template_part3();
	void CryptonightR_template_end();
	void CryptonightR_template_double_part1();
	void CryptonightR_template_double_mainloop();
	void CryptonightR_template_double_part2();
	void CryptonightR_template_double_part3();
	void CryptonightR_template_double_part4();
	void CryptonightR_template_double_end();

	void CryptonightR_soft_aes_template_part1();
	void CryptonightR_soft_aes_template_mainloop();
	void CryptonightR_soft_aes_template_part2();
	void CryptonightR_soft_aes_template_part3();
	void CryptonightR_soft_aes_template_end();
	void CryptonightR_soft_aes_template_double_part1();
	void CryptonightR_soft_aes_template_double_mainloop();
	void CryptonightR_soft_aes_template_double_part2();
	void CryptonightR_soft_aes_template_double_part3();
	void CryptonightR_soft_aes_template_double_part4();
	void CryptonightR_soft_aes_template_double_end();

	void CryptonightR_instruction0();
	void CryptonightR_instruction1();
	void CryptonightR_instruction2();
	void CryptonightR_instruction3();
	void CryptonightR_instruction4();
	void CryptonightR_instruction5();
	void CryptonightR_instruction6();
	void CryptonightR_instruction7();
	void CryptonightR_instruction8();
	void CryptonightR_instruction9();
	void CryptonightR_instruction10();
	void CryptonightR_instruction11();
	void CryptonightR_instruction12();
	void CryptonightR_instruction13();
	void CryptonightR_instruction14();
	void CryptonightR_instruction15();
	void CryptonightR_instruction16();
	void CryptonightR_instruction17();
	void CryptonightR_instruction18();
	void CryptonightR_instruction19();
	void CryptonightR_instruction20();
	void CryptonightR_instruction21();
	void CryptonightR_instruction22();
	void CryptonightR_instruction23();
	void CryptonightR_instruction24();
	void CryptonightR_instruction25();
	void CryptonightR_instruction26();
	void CryptonightR_instruction27();
	void CryptonightR_instruction28();
	void CryptonightR_instruction29();
	void CryptonightR_instruction30();
	void CryptonightR_instruction31();
	void CryptonightR_instruction32();
	void CryptonightR_instruction33();
	void CryptonightR_instruction34();
	void CryptonightR_instruction35();
	void CryptonightR_instruction36();
	void CryptonightR_instruction37();
	void CryptonightR_instruction38();
	void CryptonightR_instruction39();
	void CryptonightR_instruction40();
	void CryptonightR_instruction41();
	void CryptonightR_instruction42();
	void CryptonightR_instruction43();
	void CryptonightR_instruction44();
	void CryptonightR_instruction45();
	void CryptonightR_instruction46();
	void CryptonightR_instruction47();
	void CryptonightR_instruction48();
	void CryptonightR_instruction49();
	void CryptonightR_instruction50();
	void CryptonightR_instruction51();
	void CryptonightR_instruction52();
	void CryptonightR_instruction53();
	void CryptonightR_instruction54();
	void CryptonightR_instruction55();
	void CryptonightR_instruction56();
	void CryptonightR_instruction57();
	void CryptonightR_instruction58();
	void CryptonightR_instruction59();
	void CryptonightR_instruction60();
	void CryptonightR_instruction61();
	void CryptonightR_instruction62();
	void CryptonightR_instruction63();
	void CryptonightR_instruction64();
	void CryptonightR_instruction65();
	void CryptonightR_instruction66();
	void CryptonightR_instruction67();
	void CryptonightR_instruction68();
	void CryptonightR_instruction69();
	void CryptonightR_instruction70();
	void CryptonightR_instruction71();
	void CryptonightR_instruction72();
	void CryptonightR_instruction73();
	void CryptonightR_instruction74();
	void CryptonightR_instruction75();
	void CryptonightR_instruction76();
	void CryptonightR_instruction77();
	void CryptonightR_instruction78();
	void CryptonightR_instruction79();
	void CryptonightR_instruction80();
	void CryptonightR_instruction81();
	void CryptonightR_instruction82();
	void CryptonightR_instruction83();
	void CryptonightR_instruction84();
	void CryptonightR_instruction85();
	void CryptonightR_instruction86();
	void CryptonightR_instruction87();
	void CryptonightR_instruction88();
	void CryptonightR_instruction89();
	void CryptonightR_instruction90();
	void CryptonightR_instruction91();
	void CryptonightR_instruction92();
	void CryptonightR_instruction93();
	void CryptonightR_instruction94();
	void CryptonightR_instruction95();
	void CryptonightR_instruction96();
	void CryptonightR_instruction97();
	void CryptonightR_instruction98();
	void CryptonightR_instruction99();
	void CryptonightR_instruction100();
	void CryptonightR_instruction101();
	void CryptonightR_instruction102();
	void CryptonightR_instruction103();
	void CryptonightR_instruction104();
	void CryptonightR_instruction105();
	void CryptonightR_instruction106();
	void CryptonightR_instruction107();
	void CryptonightR_instruction108();
	void CryptonightR_instruction109();
	void CryptonightR_instruction110();
	void CryptonightR_instruction111();
	void CryptonightR_instruction112();
	void CryptonightR_instruction113();
	void CryptonightR_instruction114();
	void CryptonightR_instruction115();
	void CryptonightR_instruction116();
	void CryptonightR_instruction117();
	void CryptonightR_instruction118();
	void CryptonightR_instruction119();
	void CryptonightR_instruction120();
	void CryptonightR_instruction121();
	void CryptonightR_instruction122();
	void CryptonightR_instruction123();
	void CryptonightR_instruction124();
	void CryptonightR_instruction125();
	void CryptonightR_instruction126();
	void CryptonightR_instruction127();
	void CryptonightR_instruction128();
	void CryptonightR_instruction129();
	void CryptonightR_instruction130();
	void CryptonightR_instruction131();
	void CryptonightR_instruction132();
	void CryptonightR_instruction133();
	void CryptonightR_instruction134();
	void CryptonightR_instruction135();
	void CryptonightR_instruction136();
	void CryptonightR_instruction137();
	void CryptonightR_instruction138();
	void CryptonightR_instruction139();
	void CryptonightR_instruction140();
	void CryptonightR_instruction141();
	void CryptonightR_instruction142();
	void CryptonightR_instruction143();
	void CryptonightR_instruction144();
	void CryptonightR_instruction145();
	void CryptonightR_instruction146();
	void CryptonightR_instruction147();
	void CryptonightR_instruction148();
	void CryptonightR_instruction149();
	void CryptonightR_instruction150();
	void CryptonightR_instruction151();
	void CryptonightR_instruction152();
	void CryptonightR_instruction153();
	void CryptonightR_instruction154();
	void CryptonightR_instruction155();
	void CryptonightR_instruction156();
	void CryptonightR_instruction157();
	void CryptonightR_instruction158();
	void CryptonightR_instruction159();
	void CryptonightR_instruction160();
	void CryptonightR_instruction161();
	void CryptonightR_instruction162();
	void CryptonightR_instruction163();
	void CryptonightR_instruction164();
	void CryptonightR_instruction165();
	void CryptonightR_instruction166();
	void CryptonightR_instruction167();
	void CryptonightR_instruction168();
	void CryptonightR_instruction169();
	void CryptonightR_instruction170();
	void CryptonightR_instruction171();
	void CryptonightR_instruction172();
	void CryptonightR_instruction173();
	void CryptonightR_instruction174();
	void CryptonightR_instruction175();
	void CryptonightR_instruction176();
	void CryptonightR_instruction177();
	void CryptonightR_instruction178();
	void CryptonightR_instruction179();
	void CryptonightR_instruction180();
	void CryptonightR_instruction181();
	void CryptonightR_instruction182();
	void CryptonightR_instruction183();
	void CryptonightR_instruction184();
	void CryptonightR_instruction185();
	void CryptonightR_instruction186();
	void CryptonightR_instruction187();
	void CryptonightR_instruction188();
	void CryptonightR_instruction189();
	void CryptonightR_instruction190();
	void CryptonightR_instruction191();
	void CryptonightR_instruction192();
	void CryptonightR_instruction193();
	void CryptonightR_instruction194();
	void CryptonightR_instruction195();
	void CryptonightR_instruction196();
	void CryptonightR_instruction197();
	void CryptonightR_instruction198();
	void CryptonightR_instruction199();
	void CryptonightR_instruction200();
	void CryptonightR_instruction201();
	void CryptonightR_instruction202();
	void CryptonightR_instruction203();
	void CryptonightR_instruction204();
	void CryptonightR_instruction205();
	void CryptonightR_instruction206();
	void CryptonightR_instruction207();
	void CryptonightR_instruction208();
	void CryptonightR_instruction209();
	void CryptonightR_instruction210();
	void CryptonightR_instruction211();
	void CryptonightR_instruction212();
	void CryptonightR_instruction213();
	void CryptonightR_instruction214();
	void CryptonightR_instruction215();
	void CryptonightR_instruction216();
	void CryptonightR_instruction217();
	void CryptonightR_instruction218();
	void CryptonightR_instruction219();
	void CryptonightR_instruction220();
	void CryptonightR_instruction221();
	void CryptonightR_instruction222();
	void CryptonightR_instruction223();
	void CryptonightR_instruction224();
	void CryptonightR_instruction225();
	void CryptonightR_instruction226();
	void CryptonightR_instruction227();
	void CryptonightR_instruction228();
	void CryptonightR_instruction229();
	void CryptonightR_instruction230();
	void CryptonightR_instruction231();
	void CryptonightR_instruction232();
	void CryptonightR_instruction233();
	void CryptonightR_instruction234();
	void CryptonightR_instruction235();
	void CryptonightR_instruction236();
	void CryptonightR_instruction237();
	void CryptonightR_instruction238();
	void CryptonightR_instruction239();
	void CryptonightR_instruction240();
	void CryptonightR_instruction241();
	void CryptonightR_instruction242();
	void CryptonightR_instruction243();
	void CryptonightR_instruction244();
	void CryptonightR_instruction245();
	void CryptonightR_instruction246();
	void CryptonightR_instruction247();
	void CryptonightR_instruction248();
	void CryptonightR_instruction249();
	void CryptonightR_instruction250();
	void CryptonightR_instruction251();
	void CryptonightR_instruction252();
	void CryptonightR_instruction253();
	void CryptonightR_instruction254();
	void CryptonightR_instruction255();
	void CryptonightR_instruction256();
	void CryptonightR_instruction_mov0();
	void CryptonightR_instruction_mov1();
	void CryptonightR_instruction_mov2();
	void CryptonightR_instruction_mov3();
	void CryptonightR_instruction_mov4();
	void CryptonightR_instruction_mov5();
	void CryptonightR_instruction_mov6();
	void CryptonightR_instruction_mov7();
	void CryptonightR_instruction_mov8();
	void CryptonightR_instruction_mov9();
	void CryptonightR_instruction_mov10();
	void CryptonightR_instruction_mov11();
	void CryptonightR_instruction_mov12();
	void CryptonightR_instruction_mov13();
	void CryptonightR_instruction_mov14();
	void CryptonightR_instruction_mov15();
	void CryptonightR_instruction_mov16();
	void CryptonightR_instruction_mov17();
	void CryptonightR_instruction_mov18();
	void CryptonightR_instruction_mov19();
	void CryptonightR_instruction_mov20();
	void CryptonightR_instruction_mov21();
	void CryptonightR_instruction_mov22();
	void CryptonightR_instruction_mov23();
	void CryptonightR_instruction_mov24();
	void CryptonightR_instruction_mov25();
	void CryptonightR_instruction_mov26();
	void CryptonightR_instruction_mov27();
	void CryptonightR_instruction_mov28();
	void CryptonightR_instruction_mov29();
	void CryptonightR_instruction_mov30();
	void CryptonightR_instruction_mov31();
	void CryptonightR_instruction_mov32();
	void CryptonightR_instruction_mov33();
	void CryptonightR_instruction_mov34();
	void CryptonightR_instruction_mov35();
	void CryptonightR_instruction_mov36();
	void CryptonightR_instruction_mov37();
	void CryptonightR_instruction_mov38();
	void CryptonightR_instruction_mov39();
	void CryptonightR_instruction_mov40();
	void CryptonightR_instruction_mov41();
	void CryptonightR_instruction_mov42();
	void CryptonightR_instruction_mov43();
	void CryptonightR_instruction_mov44();
	void CryptonightR_instruction_mov45();
	void CryptonightR_instruction_mov46();
	void CryptonightR_instruction_mov47();
	void CryptonightR_instruction_mov48();
	void CryptonightR_instruction_mov49();
	void CryptonightR_instruction_mov50();
	void CryptonightR_instruction_mov51();
	void CryptonightR_instruction_mov52();
	void CryptonightR_instruction_mov53();
	void CryptonightR_instruction_mov54();
	void CryptonightR_instruction_mov55();
	void CryptonightR_instruction_mov56();
	void CryptonightR_instruction_mov57();
	void CryptonightR_instruction_mov58();
	void CryptonightR_instruction_mov59();
	void CryptonightR_instruction_mov60();
	void CryptonightR_instruction_mov61();
	void CryptonightR_instruction_mov62();
	void CryptonightR_instruction_mov63();
	void CryptonightR_instruction_mov64();
	void CryptonightR_instruction_mov65();
	void CryptonightR_instruction_mov66();
	void CryptonightR_instruction_mov67();
	void CryptonightR_instruction_mov68();
	void CryptonightR_instruction_mov69();
	void CryptonightR_instruction_mov70();
	void CryptonightR_instruction_mov71();
	void CryptonightR_instruction_mov72();
	void CryptonightR_instruction_mov73();
	void CryptonightR_instruction_mov74();
	void CryptonightR_instruction_mov75();
	void CryptonightR_instruction_mov76();
	void CryptonightR_instruction_mov77();
	void CryptonightR_instruction_mov78();
	void CryptonightR_instruction_mov79();
	void CryptonightR_instruction_mov80();
	void CryptonightR_instruction_mov81();
	void CryptonightR_instruction_mov82();
	void CryptonightR_instruction_mov83();
	void CryptonightR_instruction_mov84();
	void CryptonightR_instruction_mov85();
	void CryptonightR_instruction_mov86();
	void CryptonightR_instruction_mov87();
	void CryptonightR_instruction_mov88();
	void CryptonightR_instruction_mov89();
	void CryptonightR_instruction_mov90();
	void CryptonightR_instruction_mov91();
	void CryptonightR_instruction_mov92();
	void CryptonightR_instruction_mov93();
	void CryptonightR_instruction_mov94();
	void CryptonightR_instruction_mov95();
	void CryptonightR_instruction_mov96();
	void CryptonightR_instruction_mov97();
	void CryptonightR_instruction_mov98();
	void CryptonightR_instruction_mov99();
	void CryptonightR_instruction_mov100();
	void CryptonightR_instruction_mov101();
	void CryptonightR_instruction_mov102();
	void CryptonightR_instruction_mov103();
	void CryptonightR_instruction_mov104();
	void CryptonightR_instruction_mov105();
	void CryptonightR_instruction_mov106();
	void CryptonightR_instruction_mov107();
	void CryptonightR_instruction_mov108();
	void CryptonightR_instruction_mov109();
	void CryptonightR_instruction_mov110();
	void CryptonightR_instruction_mov111();
	void CryptonightR_instruction_mov112();
	void CryptonightR_instruction_mov113();
	void CryptonightR_instruction_mov114();
	void CryptonightR_instruction_mov115();
	void CryptonightR_instruction_mov116();
	void CryptonightR_instruction_mov117();
	void CryptonightR_instruction_mov118();
	void CryptonightR_instruction_mov119();
	void CryptonightR_instruction_mov120();
	void CryptonightR_instruction_mov121();
	void CryptonightR_instruction_mov122();
	void CryptonightR_instruction_mov123();
	void CryptonightR_instruction_mov124();
	void CryptonightR_instruction_mov125();
	void CryptonightR_instruction_mov126();
	void CryptonightR_instruction_mov127();
	void CryptonightR_instruction_mov128();
	void CryptonightR_instruction_mov129();
	void CryptonightR_instruction_mov130();
	void CryptonightR_instruction_mov131();
	void CryptonightR_instruction_mov132();
	void CryptonightR_instruction_mov133();
	void CryptonightR_instruction_mov134();
	void CryptonightR_instruction_mov135();
	void CryptonightR_instruction_mov136();
	void CryptonightR_instruction_mov137();
	void CryptonightR_instruction_mov138();
	void CryptonightR_instruction_mov139();
	void CryptonightR_instruction_mov140();
	void CryptonightR_instruction_mov141();
	void CryptonightR_instruction_mov142();
	void CryptonightR_instruction_mov143();
	void CryptonightR_instruction_mov144();
	void CryptonightR_instruction_mov145();
	void CryptonightR_instruction_mov146();
	void CryptonightR_instruction_mov147();
	void CryptonightR_instruction_mov148();
	void CryptonightR_instruction_mov149();
	void CryptonightR_instruction_mov150();
	void CryptonightR_instruction_mov151();
	void CryptonightR_instruction_mov152();
	void CryptonightR_instruction_mov153();
	void CryptonightR_instruction_mov154();
	void CryptonightR_instruction_mov155();
	void CryptonightR_instruction_mov156();
	void CryptonightR_instruction_mov157();
	void CryptonightR_instruction_mov158();
	void CryptonightR_instruction_mov159();
	void CryptonightR_instruction_mov160();
	void CryptonightR_instruction_mov161();
	void CryptonightR_instruction_mov162();
	void CryptonightR_instruction_mov163();
	void CryptonightR_instruction_mov164();
	void CryptonightR_instruction_mov165();
	void CryptonightR_instruction_mov166();
	void CryptonightR_instruction_mov167();
	void CryptonightR_instruction_mov168();
	void CryptonightR_instruction_mov169();
	void CryptonightR_instruction_mov170();
	void CryptonightR_instruction_mov171();
	void CryptonightR_instruction_mov172();
	void CryptonightR_instruction_mov173();
	void CryptonightR_instruction_mov174();
	void CryptonightR_instruction_mov175();
	void CryptonightR_instruction_mov176();
	void CryptonightR_instruction_mov177();
	void CryptonightR_instruction_mov178();
	void CryptonightR_instruction_mov179();
	void CryptonightR_instruction_mov180();
	void CryptonightR_instruction_mov181();
	void CryptonightR_instruction_mov182();
	void CryptonightR_instruction_mov183();
	void CryptonightR_instruction_mov184();
	void CryptonightR_instruction_mov185();
	void CryptonightR_instruction_mov186();
	void CryptonightR_instruction_mov187();
	void CryptonightR_instruction_mov188();
	void CryptonightR_instruction_mov189();
	void CryptonightR_instruction_mov190();
	void CryptonightR_instruction_mov191();
	void CryptonightR_instruction_mov192();
	void CryptonightR_instruction_mov193();
	void CryptonightR_instruction_mov194();
	void CryptonightR_instruction_mov195();
	void CryptonightR_instruction_mov196();
	void CryptonightR_instruction_mov197();
	void CryptonightR_instruction_mov198();
	void CryptonightR_instruction_mov199();
	void CryptonightR_instruction_mov200();
	void CryptonightR_instruction_mov201();
	void CryptonightR_instruction_mov202();
	void CryptonightR_instruction_mov203();
	void CryptonightR_instruction_mov204();
	void CryptonightR_instruction_mov205();
	void CryptonightR_instruction_mov206();
	void CryptonightR_instruction_mov207();
	void CryptonightR_instruction_mov208();
	void CryptonightR_instruction_mov209();
	void CryptonightR_instruction_mov210();
	void CryptonightR_instruction_mov211();
	void CryptonightR_instruction_mov212();
	void CryptonightR_instruction_mov213();
	void CryptonightR_instruction_mov214();
	void CryptonightR_instruction_mov215();
	void CryptonightR_instruction_mov216();
	void CryptonightR_instruction_mov217();
	void CryptonightR_instruction_mov218();
	void CryptonightR_instruction_mov219();
	void CryptonightR_instruction_mov220();
	void CryptonightR_instruction_mov221();
	void CryptonightR_instruction_mov222();
	void CryptonightR_instruction_mov223();
	void CryptonightR_instruction_mov224();
	void CryptonightR_instruction_mov225();
	void CryptonightR_instruction_mov226();
	void CryptonightR_instruction_mov227();
	void CryptonightR_instruction_mov228();
	void CryptonightR_instruction_mov229();
	void CryptonightR_instruction_mov230();
	void CryptonightR_instruction_mov231();
	void CryptonightR_instruction_mov232();
	void CryptonightR_instruction_mov233();
	void CryptonightR_instruction_mov234();
	void CryptonightR_instruction_mov235();
	void CryptonightR_instruction_mov236();
	void CryptonightR_instruction_mov237();
	void CryptonightR_instruction_mov238();
	void CryptonightR_instruction_mov239();
	void CryptonightR_instruction_mov240();
	void CryptonightR_instruction_mov241();
	void CryptonightR_instruction_mov242();
	void CryptonightR_instruction_mov243();
	void CryptonightR_instruction_mov244();
	void CryptonightR_instruction_mov245();
	void CryptonightR_instruction_mov246();
	void CryptonightR_instruction_mov247();
	void CryptonightR_instruction_mov248();
	void CryptonightR_instruction_mov249();
	void CryptonightR_instruction_mov250();
	void CryptonightR_instruction_mov251();
	void CryptonightR_instruction_mov252();
	void CryptonightR_instruction_mov253();
	void CryptonightR_instruction_mov254();
	void CryptonightR_instruction_mov255();
	void CryptonightR_instruction_mov256();
}

const void_func instructions[257] = {
	CryptonightR_instruction0,
	CryptonightR_instruction1,
	CryptonightR_instruction2,
	CryptonightR_instruction3,
	CryptonightR_instruction4,
	CryptonightR_instruction5,
	CryptonightR_instruction6,
	CryptonightR_instruction7,
	CryptonightR_instruction8,
	CryptonightR_instruction9,
	CryptonightR_instruction10,
	CryptonightR_instruction11,
	CryptonightR_instruction12,
	CryptonightR_instruction13,
	CryptonightR_instruction14,
	CryptonightR_instruction15,
	CryptonightR_instruction16,
	CryptonightR_instruction17,
	CryptonightR_instruction18,
	CryptonightR_instruction19,
	CryptonightR_instruction20,
	CryptonightR_instruction21,
	CryptonightR_instruction22,
	CryptonightR_instruction23,
	CryptonightR_instruction24,
	CryptonightR_instruction25,
	CryptonightR_instruction26,
	CryptonightR_instruction27,
	CryptonightR_instruction28,
	CryptonightR_instruction29,
	CryptonightR_instruction30,
	CryptonightR_instruction31,
	CryptonightR_instruction32,
	CryptonightR_instruction33,
	CryptonightR_instruction34,
	CryptonightR_instruction35,
	CryptonightR_instruction36,
	CryptonightR_instruction37,
	CryptonightR_instruction38,
	CryptonightR_instruction39,
	CryptonightR_instruction40,
	CryptonightR_instruction41,
	CryptonightR_instruction42,
	CryptonightR_instruction43,
	CryptonightR_instruction44,
	CryptonightR_instruction45,
	CryptonightR_instruction46,
	CryptonightR_instruction47,
	CryptonightR_instruction48,
	CryptonightR_instruction49,
	CryptonightR_instruction50,
	CryptonightR_instruction51,
	CryptonightR_instruction52,
	CryptonightR_instruction53,
	CryptonightR_instruction54,
	CryptonightR_instruction55,
	CryptonightR_instruction56,
	CryptonightR_instruction57,
	CryptonightR_instruction58,
	CryptonightR_instruction59,
	CryptonightR_instruction60,
	CryptonightR_instruction61,
	CryptonightR_instruction62,
	CryptonightR_instruction63,
	CryptonightR_instruction64,
	CryptonightR_instruction65,
	CryptonightR_instruction66,
	CryptonightR_instruction67,
	CryptonightR_instruction68,
	CryptonightR_instruction69,
	CryptonightR_instruction70,
	CryptonightR_instruction71,
	CryptonightR_instruction72,
	CryptonightR_instruction73,
	CryptonightR_instruction74,
	CryptonightR_instruction75,
	CryptonightR_instruction76,
	CryptonightR_instruction77,
	CryptonightR_instruction78,
	CryptonightR_instruction79,
	CryptonightR_instruction80,
	CryptonightR_instruction81,
	CryptonightR_instruction82,
	CryptonightR_instruction83,
	CryptonightR_instruction84,
	CryptonightR_instruction85,
	CryptonightR_instruction86,
	CryptonightR_instruction87,
	CryptonightR_instruction88,
	CryptonightR_instruction89,
	CryptonightR_instruction90,
	CryptonightR_instruction91,
	CryptonightR_instruction92,
	CryptonightR_instruction93,
	CryptonightR_instruction94,
	CryptonightR_instruction95,
	CryptonightR_instruction96,
	CryptonightR_instruction97,
	CryptonightR_instruction98,
	CryptonightR_instruction99,
	CryptonightR_instruction100,
	CryptonightR_instruction101,
	CryptonightR_instruction102,
	CryptonightR_instruction103,
	CryptonightR_instruction104,
	CryptonightR_instruction105,
	CryptonightR_instruction106,
	CryptonightR_instruction107,
	CryptonightR_instruction108,
	CryptonightR_instruction109,
	CryptonightR_instruction110,
	CryptonightR_instruction111,
	CryptonightR_instruction112,
	CryptonightR_instruction113,
	CryptonightR_instruction114,
	CryptonightR_instruction115,
	CryptonightR_instruction116,
	CryptonightR_instruction117,
	CryptonightR_instruction118,
	CryptonightR_instruction119,
	CryptonightR_instruction120,
	CryptonightR_instruction121,
	CryptonightR_instruction122,
	CryptonightR_instruction123,
	CryptonightR_instruction124,
	CryptonightR_instruction125,
	CryptonightR_instruction126,
	CryptonightR_instruction127,
	CryptonightR_instruction128,
	CryptonightR_instruction129,
	CryptonightR_instruction130,
	CryptonightR_instruction131,
	CryptonightR_instruction132,
	CryptonightR_instruction133,
	CryptonightR_instruction134,
	CryptonightR_instruction135,
	CryptonightR_instruction136,
	CryptonightR_instruction137,
	CryptonightR_instruction138,
	CryptonightR_instruction139,
	CryptonightR_instruction140,
	CryptonightR_instruction141,
	CryptonightR_instruction142,
	CryptonightR_instruction143,
	CryptonightR_instruction144,
	CryptonightR_instruction145,
	CryptonightR_instruction146,
	CryptonightR_instruction147,
	CryptonightR_instruction148,
	CryptonightR_instruction149,
	CryptonightR_instruction150,
	CryptonightR_instruction151,
	CryptonightR_instruction152,
	CryptonightR_instruction153,
	CryptonightR_instruction154,
	CryptonightR_instruction155,
	CryptonightR_instruction156,
	CryptonightR_instruction157,
	CryptonightR_instruction158,
	CryptonightR_instruction159,
	CryptonightR_instruction160,
	CryptonightR_instruction161,
	CryptonightR_instruction162,
	CryptonightR_instruction163,
	CryptonightR_instruction164,
	CryptonightR_instruction165,
	CryptonightR_instruction166,
	CryptonightR_instruction167,
	CryptonightR_instruction168,
	CryptonightR_instruction169,
	CryptonightR_instruction170,
	CryptonightR_instruction171,
	CryptonightR_instruction172,
	CryptonightR_instruction173,
	CryptonightR_instruction174,
	CryptonightR_instruction175,
	CryptonightR_instruction176,
	CryptonightR_instruction177,
	CryptonightR_instruction178,
	CryptonightR_instruction179,
	CryptonightR_instruction180,
	CryptonightR_instruction181,
	CryptonightR_instruction182,
	CryptonightR_instruction183,
	CryptonightR_instruction184,
	CryptonightR_instruction185,
	CryptonightR_instruction186,
	CryptonightR_instruction187,
	CryptonightR_instruction188,
	CryptonightR_instruction189,
	CryptonightR_instruction190,
	CryptonightR_instruction191,
	CryptonightR_instruction192,
	CryptonightR_instruction193,
	CryptonightR_instruction194,
	CryptonightR_instruction195,
	CryptonightR_instruction196,
	CryptonightR_instruction197,
	CryptonightR_instruction198,
	CryptonightR_instruction199,
	CryptonightR_instruction200,
	CryptonightR_instruction201,
	CryptonightR_instruction202,
	CryptonightR_instruction203,
	CryptonightR_instruction204,
	CryptonightR_instruction205,
	CryptonightR_instruction206,
	CryptonightR_instruction207,
	CryptonightR_instruction208,
	CryptonightR_instruction209,
	CryptonightR_instruction210,
	CryptonightR_instruction211,
	CryptonightR_instruction212,
	CryptonightR_instruction213,
	CryptonightR_instruction214,
	CryptonightR_instruction215,
	CryptonightR_instruction216,
	CryptonightR_instruction217,
	CryptonightR_instruction218,
	CryptonightR_instruction219,
	CryptonightR_instruction220,
	CryptonightR_instruction221,
	CryptonightR_instruction222,
	CryptonightR_instruction223,
	CryptonightR_instruction224,
	CryptonightR_instruction225,
	CryptonightR_instruction226,
	CryptonightR_instruction227,
	CryptonightR_instruction228,
	CryptonightR_instruction229,
	CryptonightR_instruction230,
	CryptonightR_instruction231,
	CryptonightR_instruction232,
	CryptonightR_instruction233,
	CryptonightR_instruction234,
	CryptonightR_instruction235,
	CryptonightR_instruction236,
	CryptonightR_instruction237,
	CryptonightR_instruction238,
	CryptonightR_instruction239,
	CryptonightR_instruction240,
	CryptonightR_instruction241,
	CryptonightR_instruction242,
	CryptonightR_instruction243,
	CryptonightR_instruction244,
	CryptonightR_instruction245,
	CryptonightR_instruction246,
	CryptonightR_instruction247,
	CryptonightR_instruction248,
	CryptonightR_instruction249,
	CryptonightR_instruction250,
	CryptonightR_instruction251,
	CryptonightR_instruction252,
	CryptonightR_instruction253,
	CryptonightR_instruction254,
	CryptonightR_instruction255,
	CryptonightR_instruction256,
};

const void_func instructions_mov[257] = {
	CryptonightR_instruction_mov0,
	CryptonightR_instruction_mov1,
	CryptonightR_instruction_mov2,
	CryptonightR_instruction_mov3,
	CryptonightR_instruction_mov4,
	CryptonightR_instruction_mov5,
	CryptonightR_instruction_mov6,
	CryptonightR_instruction_mov7,
	CryptonightR_instruction_mov8,
	CryptonightR_instruction_mov9,
	CryptonightR_instruction_mov10,
	CryptonightR_instruction_mov11,
	CryptonightR_instruction_mov12,
	CryptonightR_instruction_mov13,
	CryptonightR_instruction_mov14,
	CryptonightR_instruction_mov15,
	CryptonightR_instruction_mov16,
	CryptonightR_instruction_mov17,
	CryptonightR_instruction_mov18,
	CryptonightR_instruction_mov19,
	CryptonightR_instruction_mov20,
	CryptonightR_instruction_mov21,
	CryptonightR_instruction_mov22,
	CryptonightR_instruction_mov23,
	CryptonightR_instruction_mov24,
	CryptonightR_instruction_mov25,
	CryptonightR_instruction_mov26,
	CryptonightR_instruction_mov27,
	CryptonightR_instruction_mov28,
	CryptonightR_instruction_mov29,
	CryptonightR_instruction_mov30,
	CryptonightR_instruction_mov31,
	CryptonightR_instruction_mov32,
	CryptonightR_instruction_mov33,
	CryptonightR_instruction_mov34,
	CryptonightR_instruction_mov35,
	CryptonightR_instruction_mov36,
	CryptonightR_instruction_mov37,
	CryptonightR_instruction_mov38,
	CryptonightR_instruction_mov39,
	CryptonightR_instruction_mov40,
	CryptonightR_instruction_mov41,
	CryptonightR_instruction_mov42,
	CryptonightR_instruction_mov43,
	CryptonightR_instruction_mov44,
	CryptonightR_instruction_mov45,
	CryptonightR_instruction_mov46,
	CryptonightR_instruction_mov47,
	CryptonightR_instruction_mov48,
	CryptonightR_instruction_mov49,
	CryptonightR_instruction_mov50,
	CryptonightR_instruction_mov51,
	CryptonightR_instruction_mov52,
	CryptonightR_instruction_mov53,
	CryptonightR_instruction_mov54,
	CryptonightR_instruction_mov55,
	CryptonightR_instruction_mov56,
	CryptonightR_instruction_mov57,
	CryptonightR_instruction_mov58,
	CryptonightR_instruction_mov59,
	CryptonightR_instruction_mov60,
	CryptonightR_instruction_mov61,
	CryptonightR_instruction_mov62,
	CryptonightR_instruction_mov63,
	CryptonightR_instruction_mov64,
	CryptonightR_instruction_mov65,
	CryptonightR_instruction_mov66,
	CryptonightR_instruction_mov67,
	CryptonightR_instruction_mov68,
	CryptonightR_instruction_mov69,
	CryptonightR_instruction_mov70,
	CryptonightR_instruction_mov71,
	CryptonightR_instruction_mov72,
	CryptonightR_instruction_mov73,
	CryptonightR_instruction_mov74,
	CryptonightR_instruction_mov75,
	CryptonightR_instruction_mov76,
	CryptonightR_instruction_mov77,
	CryptonightR_instruction_mov78,
	CryptonightR_instruction_mov79,
	CryptonightR_instruction_mov80,
	CryptonightR_instruction_mov81,
	CryptonightR_instruction_mov82,
	CryptonightR_instruction_mov83,
	CryptonightR_instruction_mov84,
	CryptonightR_instruction_mov85,
	CryptonightR_instruction_mov86,
	CryptonightR_instruction_mov87,
	CryptonightR_instruction_mov88,
	CryptonightR_instruction_mov89,
	CryptonightR_instruction_mov90,
	CryptonightR_instruction_mov91,
	CryptonightR_instruction_mov92,
	CryptonightR_instruction_mov93,
	CryptonightR_instruction_mov94,
	CryptonightR_instruction_mov95,
	CryptonightR_instruction_mov96,
	CryptonightR_instruction_mov97,
	CryptonightR_instruction_mov98,
	CryptonightR_instruction_mov99,
	CryptonightR_instruction_mov100,
	CryptonightR_instruction_mov101,
	CryptonightR_instruction_mov102,
	CryptonightR_instruction_mov103,
	CryptonightR_instruction_mov104,
	CryptonightR_instruction_mov105,
	CryptonightR_instruction_mov106,
	CryptonightR_instruction_mov107,
	CryptonightR_instruction_mov108,
	CryptonightR_instruction_mov109,
	CryptonightR_instruction_mov110,
	CryptonightR_instruction_mov111,
	CryptonightR_instruction_mov112,
	CryptonightR_instruction_mov113,
	CryptonightR_instruction_mov114,
	CryptonightR_instruction_mov115,
	CryptonightR_instruction_mov116,
	CryptonightR_instruction_mov117,
	CryptonightR_instruction_mov118,
	CryptonightR_instruction_mov119,
	CryptonightR_instruction_mov120,
	CryptonightR_instruction_mov121,
	CryptonightR_instruction_mov122,
	CryptonightR_instruction_mov123,
	CryptonightR_instruction_mov124,
	CryptonightR_instruction_mov125,
	CryptonightR_instruction_mov126,
	CryptonightR_instruction_mov127,
	CryptonightR_instruction_mov128,
	CryptonightR_instruction_mov129,
	CryptonightR_instruction_mov130,
	CryptonightR_instruction_mov131,
	CryptonightR_instruction_mov132,
	CryptonightR_instruction_mov133,
	CryptonightR_instruction_mov134,
	CryptonightR_instruction_mov135,
	CryptonightR_instruction_mov136,
	CryptonightR_instruction_mov137,
	CryptonightR_instruction_mov138,
	CryptonightR_instruction_mov139,
	CryptonightR_instruction_mov140,
	CryptonightR_instruction_mov141,
	CryptonightR_instruction_mov142,
	CryptonightR_instruction_mov143,
	CryptonightR_instruction_mov144,
	CryptonightR_instruction_mov145,
	CryptonightR_instruction_mov146,
	CryptonightR_instruction_mov147,
	CryptonightR_instruction_mov148,
	CryptonightR_instruction_mov149,
	CryptonightR_instruction_mov150,
	CryptonightR_instruction_mov151,
	CryptonightR_instruction_mov152,
	CryptonightR_instruction_mov153,
	CryptonightR_instruction_mov154,
	CryptonightR_instruction_mov155,
	CryptonightR_instruction_mov156,
	CryptonightR_instruction_mov157,
	CryptonightR_instruction_mov158,
	CryptonightR_instruction_mov159,
	CryptonightR_instruction_mov160,
	CryptonightR_instruction_mov161,
	CryptonightR_instruction_mov162,
	CryptonightR_instruction_mov163,
	CryptonightR_instruction_mov164,
	CryptonightR_instruction_mov165,
	CryptonightR_instruction_mov166,
	CryptonightR_instruction_mov167,
	CryptonightR_instruction_mov168,
	CryptonightR_instruction_mov169,
	CryptonightR_instruction_mov170,
	CryptonightR_instruction_mov171,
	CryptonightR_instruction_mov172,
	CryptonightR_instruction_mov173,
	CryptonightR_instruction_mov174,
	CryptonightR_instruction_mov175,
	CryptonightR_instruction_mov176,
	CryptonightR_instruction_mov177,
	CryptonightR_instruction_mov178,
	CryptonightR_instruction_mov179,
	CryptonightR_instruction_mov180,
	CryptonightR_instruction_mov181,
	CryptonightR_instruction_mov182,
	CryptonightR_instruction_mov183,
	CryptonightR_instruction_mov184,
	CryptonightR_instruction_mov185,
	CryptonightR_instruction_mov186,
	CryptonightR_instruction_mov187,
	CryptonightR_instruction_mov188,
	CryptonightR_instruction_mov189,
	CryptonightR_instruction_mov190,
	CryptonightR_instruction_mov191,
	CryptonightR_instruction_mov192,
	CryptonightR_instruction_mov193,
	CryptonightR_instruction_mov194,
	CryptonightR_instruction_mov195,
	CryptonightR_instruction_mov196,
	CryptonightR_instruction_mov197,
	CryptonightR_instruction_mov198,
	CryptonightR_instruction_mov199,
	CryptonightR_instruction_mov200,
	CryptonightR_instruction_mov201,
	CryptonightR_instruction_mov202,
	CryptonightR_instruction_mov203,
	CryptonightR_instruction_mov204,
	CryptonightR_instruction_mov205,
	CryptonightR_instruction_mov206,
	CryptonightR_instruction_mov207,
	CryptonightR_instruction_mov208,
	CryptonightR_instruction_mov209,
	CryptonightR_instruction_mov210,
	CryptonightR_instruction_mov211,
	CryptonightR_instruction_mov212,
	CryptonightR_instruction_mov213,
	CryptonightR_instruction_mov214,
	CryptonightR_instruction_mov215,
	CryptonightR_instruction_mov216,
	CryptonightR_instruction_mov217,
	CryptonightR_instruction_mov218,
	CryptonightR_instruction_mov219,
	CryptonightR_instruction_mov220,
	CryptonightR_instruction_mov221,
	CryptonightR_instruction_mov222,
	CryptonightR_instruction_mov223,
	CryptonightR_instruction_mov224,
	CryptonightR_instruction_mov225,
	CryptonightR_instruction_mov226,
	CryptonightR_instruction_mov227,
	CryptonightR_instruction_mov228,
	CryptonightR_instruction_mov229,
	CryptonightR_instruction_mov230,
	CryptonightR_instruction_mov231,
	CryptonightR_instruction_mov232,
	CryptonightR_instruction_mov233,
	CryptonightR_instruction_mov234,
	CryptonightR_instruction_mov235,
	CryptonightR_instruction_mov236,
	CryptonightR_instruction_mov237,
	CryptonightR_instruction_mov238,
	CryptonightR_instruction_mov239,
	CryptonightR_instruction_mov240,
	CryptonightR_instruction_mov241,
	CryptonightR_instruction_mov242,
	CryptonightR_instruction_mov243,
	CryptonightR_instruction_mov244,
	CryptonightR_instruction_mov245,
	CryptonightR_instruction_mov246,
	CryptonightR_instruction_mov247,
	CryptonightR_instruction_mov248,
	CryptonightR_instruction_mov249,
	CryptonightR_instruction_mov250,
	CryptonightR_instruction_mov251,
	CryptonightR_instruction_mov252,
	CryptonightR_instruction_mov253,
	CryptonightR_instruction_mov254,
	CryptonightR_instruction_mov255,
	CryptonightR_instruction_mov256,
};
